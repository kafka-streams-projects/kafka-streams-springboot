package com.learnkafkastreams.domain;

public record TotalCountWithAddress (Long count,
                                     Store store) {
}
